/**
 * @solidarity/shared — pure TS types + crypto + identity + qr + vault + vcf
 * shared by apps/expo and nitro-modules.
 *
 * Domains (one folder = one ported Swift subsystem):
 *   types/      Zod 4 schemas mirroring solidarity/Models/
 *   crypto/     @noble/* AES-GCM, HKDF, SHA-256, base64url, hex
 *   identity/   DID:key derivation, JWK encoding, ad-hoc ES256 JWT sign/verify
 *   qr/         sqc1 chunked-QR codec + reassembler
 *   vault/      Shamir SSS over GF(256)
 *   vcf/        vCard 3.0/4.0 parser used by the contact importer
 *
 * Top-level primitives (single file, no subsystem folder):
 *   canonical.ts  Deterministic JSON (recursive key sort) — shared by DAG
 *                 node ids (apps/expo/src/dag/node.ts) and JWS payloads
 *   jws.ts        The one compact-JWS sign/verify primitive for did:key
 *                 authenticated payloads (profile / challenge)
 *   challenge.ts  DID-challenge/response (Verify scan)
 *   derive.ts     Unified BIP-39 mnemonic -> P-256/secp256k1 scalar
 *                 derivation (App<->Web portability)
 *   profile.ts    Profile Record schema + Result-returning
 *                 parser
 *   publicDisclosure.ts  Presence-only, root-signed NIP-78 public claims
 *                 + strict verification and badge-pointer helpers
 *   fragment.ts   URL-fragment codec (deflate + base64url) for QR/offline
 *                 profile publication
 *   webSign.ts    App<->Web per-action remote-signing envelopes
 *                 (request/response) + fail-closed verify
 *   deviceproof/  App Attest + Android Key Attestation verifiers and p2p
 *                 witness statements (docs/ref/10 §3.11)
 *   socialProof/  social-link page checks + platform rules
 */
export * from './badges';
export * from './canonical';
export * from './cardKeyBinding';
export * from './challenge';
export * from './crypto';
export * from './derive';
export * from './deviceproof';
export * from './fragment';
export * from './handles';
export * from './identity';
export * from './importer';
export * from './jws';
export * from './nostr';
export * from './nip05';
export * from './pro';
export * from './profile';
export * from './publicDisclosure';
export * from './qr';
export * from './rootVault';
export * from './sakura';
export * from './types';
export * from './vault';
export * from './vcf';
export * from './webSign';
export * from './socialProof';
